package com.example.music_notes_player_app_setup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
